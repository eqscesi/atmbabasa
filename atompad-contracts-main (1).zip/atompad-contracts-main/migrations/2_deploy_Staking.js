const StakePool = artifacts.require("StakePool");

module.exports = async (deployer, network, accounts)=> {


  let tokenAddress = "0x48ee0cc862143772feabaf9b4757c36735d1052e";
  let stakePool = await deployer.deploy(StakePool , tokenAddress);


  
};