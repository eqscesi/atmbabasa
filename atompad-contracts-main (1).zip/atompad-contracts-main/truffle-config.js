const HDWalletProvider = require('@truffle/hdwallet-provider');
const fs = require('fs');
const mnemonic = fs.readFileSync(process.env["HOME"]+"/.stash/.secret").toString().trim();
const BINANCE_API_KEY = fs.readFileSync(process.env["HOME"]+"/.stash/.binance_apy_key").toString().trim();

module.exports = {
  plugins: [
    'truffle-plugin-verify'
  ],
  networks: {
    /*development: {
      host: "127.0.0.1",     // Localhost (default: none)
      port: 8545,            // Standard BSC port (default: none)
      network_id: "*",       // Any network (default: none)
    },*/
    testnet: {
      provider: () => new HDWalletProvider(mnemonic, `https://data-seed-prebsc-2-s1.binance.org:8545`),
      network_id: 97,
      confirmations: 2,
      timeoutBlocks: 200,
      skipDryRun: true
    },
    bsc: {
      provider: () => new HDWalletProvider(mnemonic, `https://bsc-dataseed2.binance.org`),
      network_id: 56,
      confirmations: 2,
      timeoutBlocks: 200,
      skipDryRun: true
    },
  },

  api_keys: {
    etherscan: 'MY_API_KEY',
    bscscan: BINANCE_API_KEY,
    hecoinfo: 'MY_API_KEY',
    ftmscan: 'MY_API_KEY',
    polygonscan: 'MY_API_KEY',
  },

  // Set default mocha options here, use special reporters etc.
  mocha: {
    // timeout: 100000
  },

  // Configure your compilers
  compilers: {
    solc: {
      version: "^0.7.6", // A version or constraint - Ex. "^0.5.0"
    }
  }
}
